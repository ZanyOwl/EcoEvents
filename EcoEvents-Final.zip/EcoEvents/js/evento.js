function myFunction() {
    document.getElementById("modelo").style.visibility = "visible";
}
function eventoCriado() {
        alert ("Evento Criado com Sucesso!");
        document.getElementById('modelo').style.display = "none";
    
}
function abrircriaevento(){
    document.getElementById('modelo').style.display = "block";
    }
function closeve(){
        document.getElementById('modelo').style.display = "none";
        }

