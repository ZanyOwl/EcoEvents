function myFunction() {
  if(document.getElementById("nome").value.length > 3 && (document.getElementById("email").value.length > 10) && (document.getElementById("duvidas").value.length > 2)){
    alert("Mensagem Enviada Com Sucesso, Aguarde a sua resposta!");
  }}