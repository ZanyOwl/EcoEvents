function myFunction() {
    document.getElementById("invisible").style.visibility = "visible";
    document.getElementById("invisible").innerHTML="Cadastro Feito com sucesso";
    document.getElementById("invisible2").style.visibility = "visible";
    document.getElementById("invisible2").innerHTML="Preencha todos os campos obrigatórios.";

  }